function slideClosed(el,vis){
	var elem = document.getElementById(el);
	elem.style.transition = "height 0.2s linear 0s";
	elem.style.height = "5.5%";

    var text=document.getElementById(vis);
    text.style.display="none";
}
function slideOpen(el,vise,h){

	var elem = document.getElementById(el);
	elem.style.transition = "height 0.2s linear 0s";
    
    elem.style.height =h;

    var text=document.getElementById(vise);
    text.style.display="block";

}
 //+++++++++++++++++++++++++Validation++++++++++++++++++++++++++++++++++++++
 function checkSearchForm()
 {
    if(document.getElementById("selectMenu1").value=="Select"){
        Alert.render('Please Select The Blood Group.');
        }
    else if(document.getElementById("selectMenu2").value=="0"){
        Alert.render('Please Select The City.');
        }
   else {
        var x=document.getElementById("searchLink");
            x.href="http://www.google.co.in/";
          //alert("search function will be made later on");
        }
}
function checkLoginForm()
{
    var result=true;
    if(document.getElementById("EmailAndPhone").value==""){
	result=false;
        Alert.render('Email Required.');	
        }
    else if(document.getElementById("Pass").value==""){
	result=false;
        Alert.render('Password field is empty.');
        }
	return result;
}
//+++++++++++++++++++++++++++++++++++++++++Custom Alert+++++++++++++++++++++++++++++++++++++++
 function CustomAlert(){
        this.render = function(dialog){
      //-------error sound-----------------
        var beep=new Audio();
        beep.src="beepSound.wav";
        beep.play();
      //-----------------------------------
      //-------------Display Alert---------
        var winW = window.innerWidth;
        var winH = window.innerHeight;
        var dialogoverlay = document.getElementById('dialogoverlay');
        var dialogbox = document.getElementById('dialogbox');
        dialogoverlay.style.display = "block";
        dialogoverlay.style.height = winH+"px";
        dialogbox.style.left = (winW/2) - (550 * .5)+"px";
        dialogbox.style.top = "100px";
        dialogbox.style.display = "block";
        document.getElementById('dialogboxhead').innerHTML = "Opps???";
        document.getElementById('dialogboxbody').innerHTML = dialog;
        document.getElementById('dialogboxfoot').innerHTML = '<button onclick="Alert.ok()">OK</button>';
    //-------------------------------------------------------------------
        }
	    this.ok = function(){
		document.getElementById('dialogbox').style.display = "none";
		document.getElementById('dialogoverlay').style.display = "none";
	    }
    }
var Alert = new CustomAlert();
